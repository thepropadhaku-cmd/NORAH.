import { useMemo, useRef, useState } from "react";
import {
  ArrowUp,
  Calendar,
  Database,
  GraduationCap,
  Leaf,
  Menu,
  MessageSquare,
  Mic,
  Paperclip,
  Plus,
  Settings2,
  Sparkles,
  SquareStack,
  Sun,
  Target,
} from "lucide-react";
import { trpc } from "@/lib/trpc";

type ChatMessage = { role: "user" | "assistant"; content: string };

const NAV_ITEMS = [
  { key: "conversations", label: "Conversations", icon: MessageSquare },
  { key: "today", label: "Today", icon: Calendar },
  { key: "goals", label: "Goals", icon: Target },
  { key: "memory", label: "Memory", icon: Database },
  { key: "capabilities", label: "Capabilities", icon: SquareStack },
  { key: "become", label: "Become", icon: Leaf },
] as const;

const STARTER_PROMPTS = [
  { label: "Plan my day", icon: Calendar, prompt: "Help me plan my day." },
  { label: "Help me study", icon: GraduationCap, prompt: "Help me study for my next exam." },
  { label: "Track a habit", icon: Sparkles, prompt: "Help me start tracking a new habit." },
  { label: "Organize this", icon: SquareStack, prompt: "Help me organize my thoughts." },
  { label: "Just chat", icon: MessageSquare, prompt: "" },
];

function getGreeting(date: Date) {
  const hour = date.getHours();
  if (hour < 5) return { label: "Still up", sub: "Rest matters too — I'm here either way." };
  if (hour < 12) return { label: "Good morning", sub: "A fresh start to make progress." };
  if (hour < 17) return { label: "Good afternoon", sub: "Keep the momentum going." };
  if (hour < 22) return { label: "Good evening", sub: "Still time to make it count." };
  return { label: "Good night", sub: "Wrap up gently — tomorrow is waiting." };
}

export default function Home() {
  const [activeNav, setActiveNav] = useState<string>("conversations");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const greeting = useMemo(() => getGreeting(new Date()), []);

  const scrollToBottom = () => {
    queueMicrotask(() => {
      scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
    });
  };

  const send = trpc.assistant.send.useMutation({
    onSuccess: reply => {
      setMessages(prev => [...prev, { role: "assistant", content: reply.content }]);
      scrollToBottom();
    },
    onError: () => {
      setMessages(prev => [
        ...prev,
        { role: "assistant", content: "I couldn't reach the assistant core just now. Please try again in a moment." },
      ]);
      scrollToBottom();
    },
  });

  const handleSend = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || send.isPending) return;
    const history = messages.slice(-20);
    setMessages(prev => [...prev, { role: "user", content: trimmed }]);
    setDraft("");
    send.mutate({ message: trimmed, history });
    scrollToBottom();
  };

  const hasConversation = messages.length > 0;

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#f7f6f2] text-[#20201e]">
      {/* Sidebar */}
      <aside className="hidden md:flex w-[280px] shrink-0 flex-col border-r border-[#deded6] bg-[#f2f1ea] px-5 py-6">
        <div className="flex items-center gap-3 px-1">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#4b5a3f] text-[#f2f1ea] shadow-sm">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <div className="font-display text-[15px] font-semibold tracking-[0.18em]">NORAH</div>
            <div className="eyebrow">Think · Progress · Become</div>
          </div>
        </div>

        <button
          onClick={() => {
            setMessages([]);
            setActiveNav("conversations");
          }}
          className="mt-6 flex items-center justify-between rounded-xl bg-[#4b5a3f] px-4 py-3 text-sm font-medium text-[#f2f1ea] transition hover:bg-[#414e37]"
        >
          <span className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            New conversation
          </span>
          <span className="rounded-md border border-white/25 px-1.5 py-0.5 text-[10px] opacity-80">⌘K</span>
        </button>

        <nav className="mt-6 flex flex-col gap-1">
          {NAV_ITEMS.map(item => {
            const Icon = item.icon;
            const active = activeNav === item.key;
            return (
              <button
                key={item.key}
                onClick={() => setActiveNav(item.key)}
                className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${
                  active ? "bg-[#e7e5db] font-medium text-[#20201e]" : "text-[#5c5c54] hover:bg-[#eceae1]"
                }`}
              >
                <Icon className="h-4 w-4" />
                {item.label}
                {active && item.key === "conversations" && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[#4b5a3f]" />}
              </button>
            );
          })}
        </nav>

        <div className="mt-auto space-y-4 pt-6">
          <div className="border-t border-[#deded6] pt-4 text-[11px] uppercase tracking-[0.12em] text-[#9a9a90]">
            <div>A calmer you</div>
            <div>A brighter tomorrow</div>
          </div>
          <div className="flex items-center gap-3 rounded-xl border border-[#deded6] bg-white/60 px-3 py-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#4b5a3f] text-xs font-semibold text-white">G</div>
            <div className="leading-tight">
              <div className="text-sm font-medium">Guest workspace</div>
              <div className="text-xs text-[#9a9a90]">Build a better you</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Top bar */}
        <header className="flex items-center justify-between border-b border-[#deded6] px-6 py-4">
          <div className="flex items-center gap-2 text-sm text-[#5c5c54]">
            <span className="status-dot" />
            <span>Personal workspace</span>
            <span className="text-[#c7c7bd]">/</span>
            <span className="text-[#20201e]">{hasConversation ? "Conversation" : "New conversation"}</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden items-center gap-2 sm:flex">
              <Sun className="h-4 w-4 text-[#9a9a90]" />
              <div className="leading-tight">
                <div className="text-sm font-semibold text-[#4b5a3f]">{greeting.label}</div>
                <div className="text-xs text-[#9a9a90]">{greeting.sub}</div>
              </div>
            </div>
            <div className="hidden h-6 w-px bg-[#deded6] sm:block" />
            <button className="text-[#5c5c54] hover:text-[#20201e] md:hidden" type="button">
              <Menu className="h-5 w-5" />
            </button>
            <button className="hidden text-[#5c5c54] hover:text-[#20201e] md:inline-flex" type="button">
              <Settings2 className="h-5 w-5" />
            </button>
          </div>
        </header>

        {/* Conversation area */}
        <div ref={scrollRef} className="chat-scroll flex-1 overflow-y-auto px-6 py-8">
          {!hasConversation ? (
            <div className="mx-auto max-w-2xl">
              <p className="eyebrow mb-2">Hello, I'm</p>
              <h1 className="font-display text-6xl tracking-[0.08em] text-[#3d4a34]">NORAH</h1>
              <p className="mt-4 max-w-md text-[#5c5c54]">Here to help you think clearly, make progress, and get things done.</p>
              <div className="my-6 h-px w-8 bg-[#c7c7bd]" />
              <p className="mb-3 text-sm font-medium text-[#5c5c54]">What's on your mind?</p>
              <div className="flex flex-wrap gap-2">
                {STARTER_PROMPTS.map(item => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.label}
                      type="button"
                      onClick={() => item.prompt && handleSend(item.prompt)}
                      className="flex items-center gap-2 rounded-full border border-[#deded6] bg-white px-4 py-2 text-sm text-[#20201e] transition hover:border-[#4b5a3f] hover:text-[#4b5a3f]"
                    >
                      <Icon className="h-4 w-4" />
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="mx-auto flex max-w-2xl flex-col gap-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`animate-rise max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                    message.role === "user" ? "ml-auto bg-[#4b5a3f] text-[#f7f6f2]" : "mr-auto border border-[#deded6] bg-white text-[#20201e]"
                  }`}
                >
                  {message.content}
                </div>
              ))}
              {send.isPending && (
                <div className="mr-auto flex items-center gap-1 rounded-2xl border border-[#deded6] bg-white px-4 py-3">
                  <span className="typing-dot" />
                  <span className="typing-dot delay-1" />
                  <span className="typing-dot delay-2" />
                </div>
              )}
            </div>
          )}
        </div>

        {/* Composer */}
        <div className="border-t border-[#deded6] px-6 py-5">
          <div className="mx-auto flex max-w-2xl items-center gap-3 rounded-2xl border border-[#deded6] bg-white px-4 py-3 shadow-sm">
            <button type="button" className="text-[#9a9a90] disabled:cursor-not-allowed" title="Attach a file (coming soon)" disabled>
              <Paperclip className="h-5 w-5" />
            </button>
            <textarea
              rows={1}
              value={draft}
              onChange={e => setDraft(e.target.value)}
              onKeyDown={e => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend(draft);
                }
              }}
              placeholder="Ask Norah anything..."
              className="max-h-32 flex-1 resize-none bg-transparent text-sm text-[#20201e] placeholder:text-[#9a9a90] focus:outline-none"
            />
            <button type="button" className="text-[#9a9a90] disabled:cursor-not-allowed" title="Voice input (coming soon)" disabled>
              <Mic className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => handleSend(draft)}
              disabled={!draft.trim() || send.isPending}
              className="flex h-9 w-9 items-center justify-center rounded-full bg-[#4b5a3f] text-white transition hover:bg-[#414e37] disabled:opacity-40"
            >
              <ArrowUp className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
