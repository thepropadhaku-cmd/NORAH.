import { Capacitor } from "@capacitor/core";
import { OAUTH_STATE_COOKIE, encodeOAuthState } from "@shared/const";

export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

// The Manus-hosted backend for this app. The packaged Capacitor Android build
// runs the bundled UI from its own local WebView origin (no backend attached
// there), so anything that needs to reach the real API/OAuth server must use
// this origin explicitly. The web deployment is served by this same backend,
// so window.location.origin already equals it there — no behavior change for
// web.
export const BACKEND_ORIGIN = "https://manusai-jfawovjd.manus.space";

export const getApiOrigin = () =>
  Capacitor.isNativePlatform() ? BACKEND_ORIGIN : window.location.origin;

// Start the Manus OAuth login. Call this from an event handler or effect at the
// moment you want to navigate, e.g. `onClick={() => startLogin()}`.
//
// It has SIDE EFFECTS — it mints a one-time nonce, writes the __Host- state
// cookie, and navigates immediately — so the cookie nonce always matches the
// `state` it sends. Do NOT call it during render (no `href={startLogin()}` /
// `loginUrl={...}`): each call overwrites the cookie, so a stray render-phase
// call would desync it from an in-flight login and the callback would reject it
// with "invalid oauth state". It returns void by design, so there is no URL to
// stash across renders.
export const startLogin = () => {
  const oauthPortalUrl = import.meta.env.VITE_OAUTH_PORTAL_URL;
  const appId = import.meta.env.VITE_APP_ID;
  // Use the real backend origin, not window.location.origin: on native builds
  // those differ (the packaged WebView has no backend of its own), so the
  // previous window.location.origin-based redirectUri pointed at a route
  // that does not exist inside the packaged app, and the OAuth callback
  // could never reach it.
  const redirectUri = `${getApiOrigin()}/api/oauth/callback`;

  const nonce = crypto.randomUUID();
  document.cookie = `${OAUTH_STATE_COOKIE}=${nonce}; Path=/; Max-Age=600; SameSite=None; Secure`;
  const state = encodeOAuthState({ redirectUri, nonce });

  const url = new URL(`${oauthPortalUrl}/app-auth`);
  url.searchParams.set("appId", appId);
  url.searchParams.set("redirectUri", redirectUri);
  url.searchParams.set("state", state);
  url.searchParams.set("type", "signIn");

  window.location.href = url.toString();
};
