// NORAH-owned API configuration.
//
// This is the one place the client declares where the NORAH backend lives.
// It intentionally does NOT derive the API location from window.location.origin
// (that only works when the frontend and backend share an origin — true for a
// browser tab hitting the same server, never true for a packaged Capacitor
// app, which loads its UI from a local WebView origin with no backend of its
// own). One explicit origin works correctly for both the web build and the
// Android build.
//
// Override at build time with VITE_API_BASE_URL if the backend ever moves.
export const API_BASE_URL: string =
  import.meta.env.VITE_API_BASE_URL ?? "https://manusai-jfawovjd.manus.space";

export const TRPC_URL = `${API_BASE_URL}/api/trpc`;
