import { trpc } from "@/lib/trpc";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { httpBatchLink } from "@trpc/client";
import { createRoot } from "react-dom/client";
import superjson from "superjson";
import App from "./App";
import { TRPC_URL } from "./config";
import "./index.css";

// NORAH-owned tRPC client. This milestone only calls public procedures
// (assistant.send, assistant.capabilities), so there is no OAuth
// redirect-on-401 wiring, no sessionStorage Bearer-token forwarding, and no
// reliance on browser cookies here. Session-based auth for the protected
// procedures (tasks, conversations, memory, saveContext) is a deliberately
// separate, later milestone.
const queryClient = new QueryClient();

const trpcClient = trpc.createClient({
  links: [
    httpBatchLink({
      url: TRPC_URL,
      transformer: superjson,
    }),
  ],
});

createRoot(document.getElementById("root")!).render(
  <trpc.Provider client={trpcClient} queryClient={queryClient}>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </trpc.Provider>
);
