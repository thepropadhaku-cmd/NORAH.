# NORAH Architecture v0.1 — Overview

Status: RECONCILED — Capability Contract v0.2 (file 02, verbatim/frozen)
is now the authoritative source for every declared-property field used
elsewhere in this package. Files 01, 03, 04 were revised to align to it;
see each file's own changelog section for exact edits.

## 1. Purpose

This package defines the contracts that let NORAH pursue an objective
reliably across multiple capabilities, multiple executors, and possible
failures — without hardcoding retry/substitution logic into any single
layer, and without silently claiming success it hasn't verified.

This is a specification package only. It defines no database, no API, no
UI, and no runtime code. It does not begin implementation of an
"Objective Engine."

## 2. Lifecycle

```
USER
 → OBJECTIVE
 → INTENT + CONTEXT
 → REASONING + COUNCIL
 → POLICY / AUTHORIZATION
 → CAPABILITY
 → EXECUTOR
 → VERIFICATION
 → STATE UPDATE
 → REPORT
 → MEMORY
 → OBJECTIVE FOLLOW-THROUGH
```

## 3. Layer definitions and ownership rule

The reconciliation pass fixed one governing rule across all four files:
**a property is declared exactly once, by the layer that actually owns
it, and every other layer either points to it or snapshots it — never
redeclares it.**

- **Capability (file 02, v0.2, frozen)** declares what the ability
  requires, supports, permits, risks, and guarantees: preconditions
  (§6), competency and execution mode (§7), risk (§8), side
  effects/reversibility (§9), authorization level (§10), execution
  semantics and idempotency (§12), reversal/compensation (§13), required
  verification evidence (§14), relevant execution states (§15), and
  declared guarantees (§23).
- **Executor (file 03)** declares *how* a specific implementation
  performs a capability: identity, which capabilities it supports and
  how suitably, availability, its own invocation preconditions
  (distinct from Capability's), idempotency conformance, and general
  verification trustworthiness. It does not redeclare reversibility,
  risk, or required evidence — those stay owned by Capability.
- **AttemptRecord (file 04)** records *what actually happened* during
  one execution attempt: a snapshot of the relevant Capability-declared
  properties as they applied to this attempt (mode, risk, reversibility,
  authorization level), plus what was actually observed (execution
  state, verification method used and its status, evidence obtained,
  escalation).
- **Objective (file 01)** records the user's desired outcome and its own
  lifecycle across possibly many attempts — a rollup, never a duplicate,
  of attempt-level detail.
- **Reasoning + Council** proposes which capability(ies) could serve the
  objective and, on failure, whether an alternative route exists.
  Council *recommends*. Not specified in this package.
- **Policy / Authorization** is the only layer that grants permission to
  act. Not specified in this package — referenced only via
  `authorization_ref` / `authorization_requirements_ref` pointers from
  Objective, Executor, and AttemptRecord. User authorizes where
  Capability §10 requires it; Policy enforces; Council recommends but
  never substitutes for either.
- **Memory** is user-facing, durable recollection — explicitly distinct
  from the audit trail (Objective + AttemptRecord), per Capability §18
  vs §20. v0.1 does not define Memory's contract.

## 4. Rules that were made explicit during reconciliation

Four rules were previously implicit and are now stated directly, because
each corresponds to a place a future implementer could accidentally
collapse a boundary:

1. **`execution_mode` (Capability §7) is not an authorization decision.**
   It's recorded per-attempt (`execution_mode_at_execution`, file 04) as
   a snapshot for audit and for Council/Policy to read — it never itself
   grants or blocks execution.
2. **`risk` (Capability §8) is not a permission decision.** Also
   snapshotted per-attempt (`risk_level_at_execution`, file 04) — never
   an authorization level in itself; §10 remains the sole authorization
   declaration.
3. **Executor identity is an implementation detail.** Capability and
   Objective never reference a specific `executor_id`; only AttemptRecord
   and Executor itself do. This is what makes executor substitution a
   data change, not an architecture change.
4. **Objective follow-through stays an objective-lifecycle concern**
   (`follow_through_at`, file 01), never duplicated onto Capability or
   AttemptRecord, matching Capability §19 directly.

## 5. Cross-file reference map

```
Objective.attempt_ids[]                  → AttemptRecord.attempt_id
AttemptRecord.objective_id               → Objective.objective_id
AttemptRecord.capability_id/_version     → Capability §1 (file 02)
AttemptRecord.executor_id                → Executor.executor_id (file 03)
Executor.supported_capabilities          → Capability §1 capability_id (file 02)
AttemptRecord.execution_mode_at_execution      → Capability §7
AttemptRecord.risk_level_at_execution          → Capability §8
AttemptRecord.reversibility_class_at_execution → Capability §9, or
                                                   Executor.capability_overrides[].reversibility_class_override
AttemptRecord.authorization_level_at_execution → Capability §10
AttemptRecord.verification_method_used         → Capability §14's method list
AttemptRecord.execution_state                  → Capability §15 (exact enum)
Objective.authorization_ref               → Policy/Authorization decision (external, undefined here)
Executor.authorization_requirements_ref   → Policy/Authorization gate (external, undefined here)
AttemptRecord.authorization_ref           → Policy/Authorization decision (external, undefined here)
```

## 6. Worked example used throughout this package

**Objective:** "Get my passport appointment."

Capabilities: search web, read page, extract requirements, request
missing user input, fill form, book appointment, create reminder, verify
appointment. Carried through files 01, 03, and 04 as one continuous
thread.

## 7. Explicitly out of scope for v0.1

Cost/pricing per executor; formal sub-objective dependency graphs beyond
a bare `parent_objective_id`; ML-scored executor reliability;
cross-objective scheduling/prioritization; Memory's summarization rules;
dynamic executor discovery/registration; runtime enforcement that
`verification_method_used` conforms to a given capability's declared
method list (an authoring/review-time concern, not a schema constraint);
capability marketplaces; formal negotiation protocols between
executors.

## 8. Consistency check performed after reconciliation

- `reversibility_class` (or `_at_execution`) uses the identical
  four-value Capability §9 enum in Objective, Executor's override field,
  and AttemptRecord. No file defines its own divergent value set.
- `execution_state` in AttemptRecord is the exact nine-value Capability
  §15 enum, not a paraphrase or subset.
- Objective's `status` and AttemptRecord's `execution_state` are
  confirmed as intentionally distinct, non-mirrored state machines
  (documented in file 01 §3) — a deliberate non-symmetry, not an
  unresolved gap.
- `execution_mode`, `risk`, and `authorization level` each have exactly
  one declaring layer (Capability) and exactly one recording layer
  (AttemptRecord, as a snapshot) — neither Executor nor Objective
  redeclares any of the three.
- Every `*_ref` field (`authorization_ref`,
  `authorization_requirements_ref`, `interpreted_intent_ref`,
  `execution_input_ref`, `evidence_ref`) is a pointer with no inline
  decision logic in any file.
- Capability §6 (preconditions) and Executor's `interface_requirements`
  are confirmed as genuinely different, non-overlapping scopes (capability-
  level vs. executor-level), not a naming collision — documented in file
  03 §3.
- Capability Contract v0.2 (file 02) was not modified in any way during
  this reconciliation.
