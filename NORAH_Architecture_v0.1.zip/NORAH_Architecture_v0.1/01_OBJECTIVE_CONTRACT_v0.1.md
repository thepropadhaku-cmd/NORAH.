# Objective Contract v0.1

Status: RECONCILED (see §7 changelog)

## 1. What this contract is for

An Objective is what NORAH is ultimately trying to accomplish. It is a
**state record**, not a planner: it holds what's true about the pursuit
of a goal, and lets Reasoning/Council decide what to do next by reading
that state. It must never itself encode "and then try X" — that is
Council's job, using this record as input.

The Objective must outlive any single capability or executor failure.
Capability Contract v0.2 §16.1 requires exactly this: "Preserve the
user's objective" is the first step of its failure-handling sequence,
and §19 explicitly assigns follow-through to the objective lifecycle,
"not necessarily to a single execution" — this contract is where that
requirement is actually held.

## 2. Fields

```
objective_id            : uuid
statement                : string                     (human-readable, user-facing)
status                   : enum [PENDING, ACTIVE, BLOCKED, UNKNOWN,
                                  PARTIALLY_SUCCEEDED, SUCCEEDED,
                                  FAILED, ABANDONED]
created_at               : timestamp
updated_at               : timestamp
success_criteria         : string | structured predicate
blocking_reason          : string | null              (set when status = BLOCKED)
attempt_ids              : array<attempt_id>           (pointers into AttemptRecord, file 04)
reversibility_class      : enum [NONE, REVERSIBLE, PARTIALLY_REVERSIBLE,
                                  IRREVERSIBLE] | null
authorization_ref        : pointer                     (to a Policy/Authorization decision — never inline logic)
follow_through_at        : timestamp | condition | null
parent_objective_id      : uuid | null
```

## 3. Field semantics

**`status` is a different, higher-altitude state machine than
AttemptRecord's `execution_state` (file 04) — intentionally, not by
oversight.** `execution_state` (Capability §15) describes one attempt.
`status` describes the objective as a whole, which may span many
attempts across many capabilities and executors, and includes values
that have no attempt-level meaning at all (`BLOCKED`, `ABANDONED`, and
`PENDING` before any capability has even been selected). They share some
vocabulary (`UNKNOWN`, `PARTIALLY_SUCCEEDED`, `SUCCEEDED`, `FAILED`)
because the concepts genuinely recur at both altitudes, not because the
two enums are meant to be kept in lockstep. An objective can be `ACTIVE`
while its most recent attempt is `FAILED`, because another route may
still exist.

- `UNKNOWN` is a legitimate objective-level state, not just an
  attempt-level one: it means the objective's true status cannot
  currently be established (e.g. the one attempt that could confirm it
  has `execution_state: UNKNOWN` and nothing has verified it since).
- `PARTIALLY_SUCCEEDED` exists for objectives with more than one
  meaningful outcome component (see §5). It is not a numeric percentage.

**`reversibility_class`** — a **rollup**, not an independent judgment,
now using the exact Capability §9 enum (`NONE, REVERSIBLE,
PARTIALLY_REVERSIBLE, IRREVERSIBLE`). It reflects the worst-case
declared side-effect level among the capabilities used by the
objective's attempts so far. It is `null` until at least one attempt
exists — reversibility is a property Capability declares per-capability,
so there is nothing to roll up before any capability has actually been
attempted. (v0.1 previously allowed a reversibility-flavored `UNKNOWN`
value here; that was a modeling error — reversibility is declared, not
observed, so "unknown reversibility" doesn't correspond to anything
Capability actually expresses. `null` — meaning "not yet applicable" —
replaces it.)

**`follow_through_at`** — the mechanism that prevents a stale `UNKNOWN`
from becoming a silent permanent failure, per Capability §19's
follow-through categories (no follow-up / scheduled / condition-based /
recurring monitoring). An objective in `UNKNOWN` or `BLOCKED` status
without a `follow_through_at` set is itself a defect.

**`authorization_ref`** — a pointer only, to a decision informed by
Capability §10's declared authorization level, scope, and duration. The
Objective Contract never embeds the authorization rule itself.

**`parent_objective_id`** — deliberately the only relationship field.
v0.1 does not model a full dependency graph — a single optional parent
pointer says "this objective exists because of that one," without
building scheduling or graph traversal logic prematurely.

## 4. Lifecycle

```
PENDING → ACTIVE → { SUCCEEDED
                    | PARTIALLY_SUCCEEDED
                    | FAILED
                    | ABANDONED }
              ↕
           BLOCKED / UNKNOWN  (via follow_through_at, returns to ACTIVE)
```

An objective never moves directly from `BLOCKED`/`UNKNOWN` to a terminal
state without passing back through `ACTIVE` — this guarantees
Reasoning/Council always gets a chance to re-evaluate before a stale
state hardens into a false conclusion.

## 5. Partial success — deliberately left open, not silently resolved

Naming `PARTIALLY_SUCCEEDED` does not answer "which parts count as
core." v0.1 does not attempt to formally weight or rank objective
components. `success_criteria`, when structured, should be expressed as
separable components so partial evaluation is *possible* — the judgment
of what counts as sufficient partial success is Council's job at
evaluation time.

## 6. Worked example

```
objective_id: obj-001
statement: "Get my passport appointment."
status: ACTIVE
success_criteria: { appointment_booked: true, reminder_created: true, appointment_verified: true }
reversibility_class: PARTIALLY_REVERSIBLE
attempt_ids: [att-001, att-002, att-003]
follow_through_at: null
```

If `att-002` (book appointment) has `execution_state: UNKNOWN` (file 04)
and no independent verification is available, the objective moves to
`status: UNKNOWN` with `follow_through_at` set, rather than being marked
FAILED or SUCCEEDED on insufficient evidence.

If booking later resolves to `SUCCEEDED` but reminder creation
permanently fails, the objective becomes `status: PARTIALLY_SUCCEEDED` —
the user got their appointment even though NORAH couldn't also remind
them, and the report to the user (Capability §17) should say so plainly
rather than reporting a bare "done."

## 7. Explicit non-goals for v0.1

No scheduling/priority ordering across multiple concurrent objectives.
No automatic decomposition of an objective into a fixed capability plan
— that is Reasoning/Council's ongoing responsibility.

## 8. Changelog (reconciliation)

- `reversibility_class` enum changed from an ad-hoc set (which included
  an invalid reversibility-flavored `UNKNOWN`) to the exact Capability
  §9 enum, and the field is now nullable (`null` = not yet applicable,
  replacing the old `UNKNOWN` misuse).
- Added explicit note (§3) distinguishing `status` from AttemptRecord's
  `execution_state` as intentionally different, non-mirrored state
  machines at different altitudes — this was previously implicit and a
  source of apparent (but not real) inconsistency.
- Cross-references to Capability sections (§6, §9, §10, §16, §17, §19)
  added throughout for traceability; no field semantics beyond the two
  items above were changed.
