# AttemptRecord v0.1

Status: RECONCILED (field set aligned to Capability Contract v0.2's
audit, verification, execution-state, execution-mode, risk, and
authorization requirements; see §8 changelog. Still v0.1 — this is a
reconciliation pass, not a new version.)

## 1. What this contract is for

AttemptRecord connects the chain explicitly:

```
objective → capability → executor → attempt → outcome → evidence
```

It is not a peer contract alongside Objective / Capability / Executor —
it is the record of exactly one concrete try. Its job, unchanged from
v0.1: what was tried, by what, on behalf of which objective, what
happened, how confident are we that's true, and is it safe to try again
or substitute.

**Ownership rule for this reconciliation:** Capability Contract v0.2
*declares* what is required, permitted, risked, and guaranteed for an
ability in general. AttemptRecord *records* what was actually true for
one specific attempt against that declaration. Every new field below
exists because Capability declares something that must be individually
checkable per attempt — none of them re-declare or override Capability's
content; they snapshot or reference it.

AttemptRecords are audit data, not user-facing memory (Capability §18 vs
§20 — see file 00 §3).

## 2. Fields

```
attempt_id                              : uuid
objective_id                            : uuid            (→ Objective)
capability_id                           : string           (→ Capability §1, file 02)
capability_version                      : string           (→ Capability §1 "Version:" — snapshot)
executor_id                             : string           (→ Executor, file 03)
sequence_number                         : integer           (ordering within this objective+capability)

interpreted_intent_ref                  : pointer | null    (→ Reasoning/Council output — not defined in this package)
execution_input_ref                     : pointer | null    (→ logged inputs for this attempt; not inlined)

execution_mode_at_execution             : enum [AUTONOMOUS, CONFIRMATION_REQUIRED,
                                                  DELEGATED, GUIDANCE_ONLY]           (→ Capability §7)
risk_level_at_execution                 : enum [LOW, MODERATE, HIGH, CRITICAL]        (→ Capability §8)
reversibility_class_at_execution        : enum [NONE, REVERSIBLE, PARTIALLY_REVERSIBLE,
                                                  IRREVERSIBLE]                        (→ Capability §9, or
                                                                                          Executor override — file 03 §3)
preconditions_confirmed                 : boolean | null    (→ Capability §6 — were declared preconditions checked true before this attempt)

authorization_ref                       : pointer | null    (→ Policy/Authorization decision — never inline logic)
authorization_level_at_execution        : enum [NONE, IMPLICIT, EXPLICIT, ELEVATED]    (→ Capability §10 — snapshot, not a decision)

idempotency_key                         : string | null
retry_of                                : attempt_id | null
substitution_of                         : attempt_id | null
pre_substitution_verification_completed : boolean | null

started_at                              : timestamp
completed_at                            : timestamp | null
execution_state                         : enum [PLANNED, AUTHORIZED, EXECUTING,
                                                  SUCCEEDED, FAILED, PARTIALLY_SUCCEEDED,
                                                  UNKNOWN, CANCELLED, EXPIRED]         (→ Capability §15, exact enum)

verification_method_used                : enum [API_RESPONSE, STATE_INSPECTION,
                                                  INDEPENDENT_QUERY, DEVICE_OBSERVATION,
                                                  HUMAN_CONFIRMATION, OTHER] | null    (→ Capability §14's method list)
verification_status                     : enum [VERIFIED, UNVERIFIED,
                                                  VERIFICATION_PENDING, VERIFICATION_FAILED]
evidence_ref                            : pointer | null    (→ the evidence actually obtained)

escalation_status                       : enum [NOT_REQUIRED, REQUIRED, ESCALATED]     (→ Capability §16.7)
```

## 3. What changed from v0.1, and why (ownership, not symmetry)

This reconciliation deliberately does **not** make every contract carry
the same fields. Fields were added to AttemptRecord only where Capability
v0.2 requires per-attempt evidence that no other layer can hold. Nothing
was added to Executor or Objective merely to look consistent.

- **`execution_state` replaces the old `outcome` field.** v0.1's
  `outcome` had three values (SUCCESS/FAILURE/UNKNOWN). Capability §15
  defines nine, including pre-outcome states (`PLANNED`, `AUTHORIZED`,
  `EXECUTING`) and two non-outcome terminal states (`CANCELLED`,
  `EXPIRED`) that v0.1 had no way to represent. This is now the exact
  enum from §15, not a paraphrase of it.
  - **UNKNOWN remains independent of FAILED** — both are first-class
    values in the same enum, exactly as Capability §15 requires
    ("UNKNOWN MUST NOT be represented as success or failure until
    reconciliation occurs"). This was already true in v0.1's coarser
    enum and remains true here.
- **`verification_status` is retained as a separate field from
  `execution_state`**, and is *not* itself in Capability v0.2 by that
  name — it's an AttemptRecord-owned refinement of Capability §14's
  floor rule ("no sufficient evidence = NOT VERIFIED"). Capability sets
  the minimum bar; AttemptRecord tracks *where in the verification
  process* this attempt currently sits (e.g. `VERIFICATION_PENDING` for
  "check has been requested but hasn't returned yet"), which the binary
  floor rule alone can't express. This does not contradict §14 — an
  attempt with `verification_status: UNVERIFIED` or
  `VERIFICATION_PENDING` still cannot be treated as verified success by
  the Objective layer, matching the floor rule exactly.
- **`verification_method_used`** closes the loop between what Capability
  §14 allows and what actually happened: it must be one of the methods
  Capability's own §14 declares as acceptable for that capability (that
  check happens at Council/authoring time, not encoded as a runtime
  constraint in this schema — see file 00 §7 non-goals).
- **`execution_mode_at_execution` and `risk_level_at_execution`** are
  pure snapshots of Capability §7 and §8. Per the explicit rule for this
  reconciliation: **execution_mode is not an authorization decision, and
  risk is not a permission decision.** Both fields exist only so the
  audit trail can show what mode/risk applied when the attempt ran —
  neither field grants, blocks, or implies authorization. The actual
  authorization decision is only ever referenced via `authorization_ref`.
- **`authorization_level_at_execution`** is likewise a snapshot of
  Capability §10's declared level, not a second authorization system.
  `authorization_ref` remains the sole pointer to the actual decision;
  this field just records what level that decision was made against, for
  audit continuity if the capability's declared level changes in a later
  version.
- **`reversibility_class_at_execution`** now uses the *exact* Capability
  §9 enum (`NONE, REVERSIBLE, PARTIALLY_REVERSIBLE, IRREVERSIBLE`). v0.1
  had drifted into inventing its own value set (which included a
  reversibility-flavored `UNKNOWN` that doesn't exist in Capability and
  didn't make sense — reversibility is a declared property, not an
  observed one). That drift is corrected here, and correspondingly in
  files 01 and 03 (see those changelogs).
- **`preconditions_confirmed`** is the minimum information needed to
  close the Capability §6 gap: it does not re-implement precondition
  *evaluation* (that's Council/Executor's job at execution time) — it
  only records whether that evaluation happened and passed, for this one
  attempt.
- **`capability_version`, `interpreted_intent_ref`, `execution_input_ref`,
  `escalation_status`** exist because Capability §20 (Audit) explicitly
  lists them as required audit content, and no other file in this
  package had anywhere to put them. `interpreted_intent_ref` and
  `execution_input_ref` are pointers, not inlined content — this keeps
  AttemptRecord from becoming a dumping ground for arbitrary payloads.

## 4. The core failure mode this record is built to prevent (unchanged from v0.1)

Irreversible action + UNKNOWN execution_state + executor substitution,
without verification in between, risking a duplicate irreversible side
effect performed by two independent executors with no visibility into
each other.

**Rule:** substitution onto a new executor for the same capability is
blocked unless one of the following is true:
1. The prior attempt's `execution_state` was a clean `FAILED` (not
   `UNKNOWN`), or
2. The prior attempt's `reversibility_class_at_execution` was
   `NONE` or `REVERSIBLE`, or
3. `pre_substitution_verification_completed = true` — an independent
   check was actually performed (via a capability/executor whose
   `verification_support` is `INDEPENDENTLY_VERIFIABLE`, file 03) before
   the new attempt is created.

If none of these hold, the objective (file 01) should move to `status:
UNKNOWN` with `follow_through_at` set, rather than Council silently
picking a new executor.

## 5. Idempotency and retry — sufficiency check against duplicate side effects

Capability §12 declares whether/how a capability requires idempotent
behavior in general. Executor's `idempotency_support` (file 03) declares
how a given implementation conforms to that requirement. AttemptRecord
is where the two meet for one concrete try:

- `idempotency_key` — populated by NORAH when the executor's
  `idempotency_support` is `CALLER_MANAGED`; mirrors the executor's own
  key when `NATIVE`. Derived from stable attempt inputs (objective_id +
  capability_id + a hash of `execution_input_ref`'s content) so that two
  attempts with identical inputs are recognizable as the same logical
  action even without an explicit `retry_of` link.
- `retry_of` — same executor, same capability, trying again. Governed by
  that executor's `idempotency_support`. If `NONE`, a retry must not be
  recorded without independent verification of the prior attempt first
  (§4 applies here too, not just to substitution).
- `substitution_of` — different executor, same capability. Higher risk;
  governed by the §4 rule above.

Together, `idempotency_key` (prevents the *same* executor from
duplicating an effect on retry) and the §4 substitution rule (prevents
*different* executors from duplicating an effect on substitution) are
the two mechanisms that jointly satisfy "retry/idempotency information
must be sufficient to prevent duplicate side effects." Neither alone is
sufficient — this is why both exist.

## 6. Worked example — the failure mode in practice

```
attempt_id: att-002
objective_id: obj-001
capability_id: cap-book-appointment
capability_version: "1.3"
executor_id: exec-hermes-android
sequence_number: 1
interpreted_intent_ref: intent-ref-014
execution_input_ref: input-ref-027
execution_mode_at_execution: CONFIRMATION_REQUIRED
risk_level_at_execution: MODERATE
reversibility_class_at_execution: PARTIALLY_REVERSIBLE
preconditions_confirmed: true
authorization_ref: policy-ref-004
authorization_level_at_execution: EXPLICIT
idempotency_key: null
retry_of: null
substitution_of: null
pre_substitution_verification_completed: null
started_at: 2026-09-16T10:02:00Z
completed_at: 2026-09-16T10:02:41Z
execution_state: UNKNOWN
verification_method_used: null
verification_status: UNVERIFIED
evidence_ref: null
escalation_status: NOT_REQUIRED
```

Because `execution_state: UNKNOWN` and reversibility is not `NONE` or
`REVERSIBLE`, Council cannot immediately create `att-003` on
`exec-official-passport-api` as a plain substitution. It must first
attempt `cap-verify-appointment` (an `INDEPENDENTLY_VERIFIABLE`
executor per file 03 §4). Only once that check completes does the next
AttemptRecord get created, with `pre_substitution_verification_completed:
true` and `substitution_of: att-002` set accordingly.

## 7. Explicit non-goals for v0.2

No automatic retry scheduling/backoff policy — *whether* to retry is
Council's decision informed by this record, not a rule this contract
enforces on its own. No cross-objective attempt correlation. No
numeric confidence scores on `verification_status` — it stays a small
enum, not a probability. No runtime enforcement that
`verification_method_used` matches Capability §14's declared list for a
given capability — that check belongs to whatever authors/reviews
capabilities, not to this record's schema.

## 8. Changelog (v0.1 pre-reconciliation → v0.1 reconciled)

- Renamed `outcome` → `execution_state`; expanded enum from 3 values to
  the exact 9-value Capability §15 enum.
- Added: `capability_version`, `interpreted_intent_ref`,
  `execution_input_ref`, `execution_mode_at_execution`,
  `risk_level_at_execution`, `preconditions_confirmed`,
  `authorization_ref`, `authorization_level_at_execution`,
  `verification_method_used`, `escalation_status`.
- Changed `reversibility_class_at_execution` enum from an ad-hoc set
  (which included an invalid reversibility-flavored `UNKNOWN`) to the
  exact Capability §9 enum (`NONE, REVERSIBLE, PARTIALLY_REVERSIBLE,
  IRREVERSIBLE`).
- No fields removed. `verification_status`, `evidence_ref`,
  `idempotency_key`, `retry_of`, `substitution_of`,
  `pre_substitution_verification_completed` unchanged from v0.1.
