# Executor Contract v0.1

Status: RECONCILED (see §6 changelog)

## 1. What this contract is for

An Executor is a concrete implementation that performs a capability:
native Android, an official API/integration, the NORAH backend, Hermes,
Manus, a specialist agent, or a human. **Capability Contract v0.2 §11
requires that a capability remain independent of any specific executor
implementation where practical** — this contract is what makes that
possible: it describes what an executor *can* do and how well, so that
substituting one executor for another (on failure) is a data lookup, not
a code change.

**Executor identity is an implementation detail.** Nothing in Capability
(file 02) or Objective (file 01) references a specific `executor_id` —
they operate in terms of capabilities and outcomes. Only AttemptRecord
(file 04) and this contract know which concrete executor did the work.

**Competency does not grant authorization.** An Executor Contract entry
describes what an executor *can* do — it never grants permission to do
it. Permission is always a pointer to the Policy/Authorization layer
(`authorization_requirements_ref`).

## 2. Fields

```
executor_id                    : string
executor_type                  : enum [native_android, official_api,
                                         norah_backend, hermes, manus,
                                         specialist_agent, human]
supported_capabilities         : array<capability_id>
capability_overrides           : array<CapabilityOverride>   (see §3)
availability_status            : enum [AVAILABLE, DEGRADED, UNAVAILABLE, UNKNOWN]
interface_requirements         : string | structured   (see §3 — executor-level only)
idempotency_support             : enum [NATIVE, CALLER_MANAGED, NONE]
verification_support            : enum [SELF_REPORTED, INDEPENDENTLY_VERIFIABLE,
                                          UNVERIFIABLE]
authorization_requirements_ref  : pointer   (to a Policy/Authorization gate — never inline logic)
trust_tier                      : enum [TRUSTED, PROVISIONAL, UNTRUSTED]
```

`CapabilityOverride` (embedded, one per capability this executor
supports with a notable difference from its general profile):
```
capability_id                 : string
suitability                    : enum [PREFERRED, ACCEPTABLE, LAST_RESORT]
reversibility_class_override   : enum [NONE, REVERSIBLE, PARTIALLY_REVERSIBLE,
                                         IRREVERSIBLE] | null
notes                           : string | null
```

## 3. Field semantics

**Reversibility is owned entirely by Capability §9 — Executor does not
declare its own.** v0.1 previously had a top-level `reversibility_class`
field on Executor, which duplicated Capability's declaration and
introduced an inconsistent value set. That field is removed. The *only*
place an executor can differ from the capability's declared side-effect
level is `capability_overrides[].reversibility_class_override`, and only
for the specific capability named — the absence of an override means the
capability's own declared value (file 02 §9) applies unchanged. This is
a genuine exception case (an implementation that happens to make an
otherwise-irreversible action reversible, e.g. by keeping a compensating
record), not a general-purpose field, which is why it lives nested under
`capability_overrides` rather than at the top level.

**`capability_overrides` / `suitability`** — an executor can be
`AVAILABLE` and technically `supported` for a capability while still
being a poor fit for it right now (e.g. a human executor is `ACCEPTABLE`
for "fill form" but `LAST_RESORT` for "search web"). Suitability is a
hint Council reads; it is not itself an authorization decision.

**`interface_requirements`** — states what must be true for *this
executor* to be invokable (e.g. "requires Android CALENDAR permission,"
"requires a valid OAuth token for the passport office's official
portal"). This is deliberately narrower than Capability §6
(Preconditions): §6 preconditions belong to the capability itself and
must hold regardless of which executor is chosen (e.g. "target uniquely
resolved"); `interface_requirements` covers only what this specific
implementation additionally needs to be reachable/callable. Both are
checked before an attempt; only the executor-level check belongs here.
Whether the capability-level preconditions were confirmed is recorded on
the attempt itself (file 04, `preconditions_confirmed`), not duplicated
into this contract.

**`idempotency_support`** — describes how this implementation conforms
to whatever idempotency behavior Capability §12 requires for a given
capability, not an independently-invented property:
- `NATIVE` — the executor itself guarantees repeat calls with the same
  input have no additional effect (e.g. an API with an idempotency-key
  parameter).
- `CALLER_MANAGED` — NORAH must supply its own idempotency key or dedup
  logic (tracked via AttemptRecord, file 04) before it's safe to retry.
- `NONE` — retrying this executor for this capability is inherently
  unsafe and must not be attempted without independent verification
  first, regardless of declared reversibility.

**`verification_support`** (renamed from `verification_method` in the
prior draft) — this is *not* a redeclaration of Capability §14's
required evidence or its six-value method list. It is a coarse signal
of how much this executor's own report can be trusted in general:
- `SELF_REPORTED` — executor says it succeeded; no other confirmation
  exists.
- `INDEPENDENTLY_VERIFIABLE` — a separate check exists through this
  executor or another (e.g. "verify appointment" as its own capability).
- `UNVERIFIABLE` — no way to confirm beyond the executor's own claim.

Which specific method (from Capability §14's list) was actually used for
a given attempt is recorded on the attempt itself
(`verification_method_used`, file 04) — this field only says whether
*any* adequate verification is possible through this executor at all.

**`trust_tier`** — deliberately coarse, not a numeric score, and
unrelated to authorization: a signal for how much scrutiny an executor's
report deserves, not a decision about what it's allowed to do.

## 4. Worked example

```
executor_id: exec-hermes-android
executor_type: hermes
supported_capabilities: [cap-fill-form, cap-book-appointment]
capability_overrides:
  - capability_id: cap-book-appointment
    suitability: ACCEPTABLE
    reversibility_class_override: null
    notes: "Can complete booking flow but has no independent confirmation step."
availability_status: AVAILABLE
interface_requirements: "Requires Hermes backend reachable on local network; requires accessibility-service permission on device."
idempotency_support: CALLER_MANAGED
verification_support: SELF_REPORTED
authorization_requirements_ref: policy-ref-004
trust_tier: PROVISIONAL
```

```
executor_id: exec-official-passport-api
executor_type: official_api
supported_capabilities: [cap-book-appointment, cap-verify-appointment]
availability_status: AVAILABLE
interface_requirements: "Requires valid OAuth token for the passport office portal."
idempotency_support: NATIVE
verification_support: INDEPENDENTLY_VERIFIABLE
authorization_requirements_ref: policy-ref-004
trust_tier: TRUSTED
```

Neither executor declares its own reversibility — both defer to
Capability §9's declared side-effect level for `cap-book-appointment`
unless a `capability_overrides` entry says otherwise (here, neither
does).

## 5. Explicit non-goals for v0.1

No dynamic executor discovery/registration — the set of executors is
assumed static and curated. No cost/pricing metadata. No automated
trust-tier promotion/demotion logic. No executor-declared risk level —
risk is owned entirely by Capability §8, snapshotted per-attempt (file
04), never duplicated here.

## 6. Changelog (reconciliation)

- Removed top-level `reversibility_class` field. Reversibility is owned
  by Capability §9; the only executor-level exception mechanism is the
  existing `capability_overrides[].reversibility_class_override`, whose
  enum now matches Capability §9 exactly (`NONE, REVERSIBLE,
  PARTIALLY_REVERSIBLE, IRREVERSIBLE`).
- Renamed `verification_method` → `verification_support` and clarified
  it as a coarse trust signal distinct from Capability §14's specific
  method list (now tracked per-attempt in file 04 as
  `verification_method_used`).
- Clarified `interface_requirements` as executor-level-only, explicitly
  distinct from Capability §6 preconditions.
- Clarified `idempotency_support` as conformance to Capability §12's
  requirement, not an independent declaration.
