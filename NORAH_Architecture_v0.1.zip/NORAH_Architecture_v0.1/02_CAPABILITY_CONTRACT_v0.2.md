# NORAH Capability Contract v0.2

Status: APPROVED BASELINE (verbatim — not modified by this package)

---

A capability is a modular, bounded ability through which NORAH
can produce a defined real-world effect.

A capability MUST NOT be treated as proof that execution is
available, authorized, or successful.


1. IDENTITY

Capability ID:
Capability name:
Version:
Owner/module:
Status:


2. PURPOSE

What real-world outcome does this capability provide?

Define the outcome in user-level terms.


3. SCOPE

What operations does this capability support?

Explicitly define supported operations and targets.


4. BOUNDARIES

What can this capability NOT do?

Explicitly define unsupported operations,
resource boundaries and forbidden behavior.


5. INPUT CONTRACT

Required inputs:
Optional inputs:
Input formats:
Ambiguous-input handling:


6. PRECONDITIONS

What must be true before execution?

Examples:
- authentication available
- target uniquely resolved
- required resource exists
- required permissions granted
- required service available


7. COMPETENCY

The capability declares:

AVAILABLE:
Can this capability currently execute?

SUPPORTED:
Can this capability perform this operation?

SUITABILITY:
Is this capability appropriate for this specific objective?

EXECUTION MODES:
- autonomous
- confirmation-required
- delegated
- guidance-only

Competency does NOT grant authorization.


8. RISK

Risk level:
- LOW
- MODERATE
- HIGH
- CRITICAL

Potential consequences of incorrect execution:


9. SIDE EFFECTS

Side-effect level:
- NONE
- REVERSIBLE
- PARTIALLY_REVERSIBLE
- IRREVERSIBLE

Describe all meaningful external effects.


10. PERMISSION / AUTHORIZATION

Required authorization level:
- NONE
- IMPLICIT
- EXPLICIT
- ELEVATED

Authorization scope:
Authorization duration:
Can authorization be delegated?
Can authorization survive retries?
Can authorization survive plan changes?


11. EXECUTOR

Required executor interface:

Possible implementations:
- native Android API
- official integration
- NORAH backend
- Hermes
- Manus
- specialist agent
- human

The capability MUST remain independent of any specific executor
implementation where practical.


12. EXECUTION

Execution input:
Execution procedure/interface:
Timeout:
Retry policy:
Concurrency rules:
Idempotency:
Idempotency key, if supported:


13. REVERSAL / COMPENSATION

Can the action be reversed?

If yes:
- reversal capability
- conditions
- time window

If no:
- explicitly state irreversible effects.


14. VERIFICATION

Required evidence of success:

Verification method:
- API response
- state inspection
- independent query
- device observation
- human confirmation
- other

The capability MUST define what constitutes sufficient evidence.

No sufficient evidence = NOT VERIFIED.


15. EXECUTION STATE

Possible states:

PLANNED
AUTHORIZED
EXECUTING
SUCCEEDED
FAILED
PARTIALLY_SUCCEEDED
UNKNOWN
CANCELLED
EXPIRED

UNKNOWN MUST NOT be represented as success or failure
until reconciliation occurs.


16. FAILURE HANDLING

On failure:

1. Preserve the user's objective.
2. Record the failure.
3. Determine whether the operation may have occurred.
4. Attempt verification/reconciliation where appropriate.
5. Determine whether another valid capability exists.
6. Retry only when safe.
7. Escalate when required.
8. Never fabricate success.


17. REPORTING

Define what NORAH should tell the user.

The report MUST distinguish:

- planned
- attempted
- succeeded
- verified
- failed
- partially completed
- unknown


18. MEMORY

Define what information is eligible for persistence.

Examples:

- objective
- relevant user preference
- resulting state
- important decision
- recurring pattern
- authorization preference

Do NOT automatically persist all execution data.


19. FOLLOW-THROUGH

Declare whether completion requires:

- no follow-up
- scheduled follow-up
- condition-based follow-up
- recurring monitoring

Follow-through belongs to the objective lifecycle,
not necessarily to a single execution.


20. AUDIT

Retain internally:

- objective
- interpreted intent
- selected capability
- capability version
- executor
- authorization state
- relevant inputs
- execution attempt
- execution state
- verification evidence
- failure/escalation
- final outcome

Audit records MUST be distinguishable from user-facing memory.


21. COMPOSABILITY

Define:

- can this capability be used inside a multi-step plan?
- dependencies
- outputs
- capabilities it can invoke
- capabilities that may consume its output


22. VERSIONING

Capability changes MUST be versioned.

Changes to:
- scope
- boundaries
- permissions
- risk
- verification
- execution semantics

require a new capability version or explicit migration.


23. DECLARED GUARANTEES

What does this capability guarantee?

What does it explicitly NOT guarantee?
